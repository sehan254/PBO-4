package Overloading;

public class Resep {
    void tampilkanResep(String bahan) {
        System.out.println("Resep dengan bahan: " + bahan);
    }

    void tampilkanResep(String bahan1, String bahan2) {
        System.out.println("Resep dengan dua bahan: " + bahan1 + " dan " + bahan2);
    }

    void tampilkanResep(int jumlahBahan) {
        System.out.println("Menampilkan resep dengan " + jumlahBahan + " bahan.");
    }

    public static void main(String[] args) {
        Resep r = new Resep();
        r.tampilkanResep("Telur");
        r.tampilkanResep("Ayam", "Cabe");
        r.tampilkanResep(5);
    }
}
