package Overloading;

public class PemesananMakanan {
    void pesan(String menu) {
        System.out.println("Memesan: " + menu);
    }

    void pesan(String menu, int jumlah) {
        System.out.println("Memesan: " + jumlah + " porsi " + menu);
    }

    void pesan(String menu, boolean bawaPulang) {
        String jenis = bawaPulang ? "dibungkus" : "makan di tempat";
        System.out.println("Memesan: " + menu + " untuk " + jenis);
    }

    public static void main(String[] args) {
        PemesananMakanan p = new PemesananMakanan();
        p.pesan("Nasi Goreng");
        p.pesan("Sate Ayam", 2);
        p.pesan("Bakso", true);
    }
}

